# package_name

__Description:__   
The package image-processing is used to:  
	Process images using histogram matching and structural similarity in processing, also allowing image resizing.  
	The utilities package reads the images, saves them and plots their results
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing
```

## Author
Italo

## License
[MIT](https://choosealicense.com/licenses/mit/)